package com.flipkart.pages;

 

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.List;

 

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

 

import com.webdriverUtils.Commonfunctions;
import com.webdriverUtils.ConfigFileReader;

 

public class SearchScreenPage extends Commonfunctions {
    @FindBy(xpath = "//input[@title='Search for products, brands and more']")
    public WebElement searchbar;

 

    @FindBy(xpath = "//button[@class='vh79eN']")
    public WebElement searchicon;

 

    @FindBy(xpath = "//a[class='_31qSD5']")
    public WebElement display_result;

 

    @FindBy(xpath = "//div[@class='_3wU53n']")
    public WebElement phone_name;

 

    public void launchURL() throws InterruptedException,

 

            FileNotFoundException {
        ConfigFileReader cf = new ConfigFileReader();
        driver.get(cf.getApplicationUrl());

 

    }

 

    public void enterSearchKeyword()

 

    {
        try {

 

            enter(searchbar, "Mobile");

 

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

 

    public void clickSearchIcon() throws InterruptedException

 

    {

 

        try {

 

            jsClick(searchicon);

 

        } catch (Exception e) {

 

            e.printStackTrace();

 

        }

 

    }

 

    public void getSearchResult()

 

    {
        try {

 

            getText(display_result);
        } catch (Exception e) {
            e.printStackTrace();
        }

 

    }

 

    public void getPhoneName() {
        try {

 

            getText(phone_name);
        } catch (Exception e) {
            e.printStackTrace();
        }

 

    }

 

}