package com.flipkart.StepDefination;

 

import org.openqa.selenium.support.PageFactory;

 

import com.flipkart.pages.SearchScreenPage;
import com.webdriverUtils.Commonfunctions;

 

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

 

 

public class FlipkartSearchSD extends Commonfunctions {

 

    //searchs search=PageFactory.initElements(driver,searchs.class);
    SearchScreenPage search= new SearchScreenPage();
    @Given("^Navigate to \"([^\"]*)\"$")
    public void navigate_to(String arg1) throws Throwable {
        driverSetup();
        search.launchURL();
        
    }
        
    

 

    @When("^Search for Mobiles$")
    public void enter_search() throws Throwable {
        search.enterSearchKeyword();
        
    }

 

    @And("^Click the search icon$")
    public void click_search_icon() throws Throwable {
        search.clickSearchIcon();
        
    }

 

    @When("^Search result is displayed$")
    public void get_display_result() throws Throwable {
        
        search.getSearchResult();
    }
    @Then("^Get phone details$")
    public void get_phone_text() throws Throwable {
        search.getPhoneName();
}
}